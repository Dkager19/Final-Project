# example-binder
Example of a simple binder containing a Jupyter notebook that creates plot of random data

[![Binder](https://mybinder.org/badge_logo.svg)](https://mybinder.org/v2/gh/alightbody/example-binder/HEAD)
